# NeuroMarketing 2.0 Advisor — Backend Orchestratore (scheletro)

Scheletro del backend che esegue la **catena CMIOV** sui prompt della libreria,
gestisce gli **asset multimodali** (testo / URL / immagine / PDF) e applica un
**Quality Gate** finale. Rispecchia il blueprint dell'architettura: Router →
Conosci → Misura → Interpreta → Ottimizza → Verifica → Quality Gate.

> È un **punto di partenza**: le parti centrali funzionano, alcune sono `# TODO`
> (router reale dalla mappa problemi, persistenza su DB, autenticazione, eval).

## Struttura

```
nm20_backend/
├─ app/
│  ├─ config.py            # configurazione da variabili d'ambiente (API key inclusa)
│  ├─ anthropic_client.py  # wrapper Messages API + estrazione testo + tool web
│  ├─ assets.py            # Asset -> blocchi multimodali (image/document/testo+url)
│  ├─ library.py           # carica lib_data.json (i tuoi 111 prompt)
│  ├─ assessment.py        # modello a due livelli: ProfiloAzienda + BriefAnalisi
│  ├─ router.py            # pianifica: problema -> sequenza di Step CMIOV
│  ├─ cmiov.py             # Orchestratore: esegue la catena accumulando il dossier
│  ├─ quality_gate.py      # report finale: fatti vs ipotesi, rischi, azioni
│  └─ main.py              # FastAPI: /pianifica, /esegui, /clienti/{id}/memoria
├─ data/
│  ├─ lib_data.sample.json # 6 schede d'esempio (sostituisci col tuo file reale)
│  └─ memoria/             # memoria per cliente (creata a runtime)
├─ requirements.txt
└─ .env.example
```

## Avvio (Windows)

```bat
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

copy .env.example .env
:: apri .env e incolla la tua ANTHROPIC_API_KEY

uvicorn app.main:app --reload
```

Poi apri http://127.0.0.1:8000/docs per provare gli endpoint dall'interfaccia.

Per usare la tua libreria reale: imposta `LIB_DATA_PATH` nel `.env` sul percorso
del tuo `lib_data.json` (altrimenti parte con le schede di esempio).

## Dati a due livelli (assessment + brief)

Per non richiedere gli stessi dati a ogni analisi, i dati sono separati su due livelli
(vedi `app/assessment.py`):

- **Livello 1 — Profilo Azienda (assessment, una tantum):** dati ed esigenze
  dell'azienda, validi per tutti i processi. Si compilano una volta e diventano la
  memoria del cliente, alimentando la fase Conosci.
  `PUT /clienti/{id}/profilo` per crearlo/aggiornarlo, `GET` per leggerlo (con % di completezza).
- **Livello 2 — Brief Analisi (specifico):** solo il delta della singola analisi
  (problema, azione, domanda di ricerca, metrica target, vincoli). Eredita il profilo
  via `cliente_id`; può fare `override_profilo` puntuale senza toccare il profilo.

Niente duplicazione: il profilo è il punto unico di verità; ogni analisi salva lo
`contesto_snapshot` effettivamente usato, per tracciabilità.

## Flusso d'uso (i due checkpoint umani del blueprint)

0. **PUT `/clienti/{id}/profilo`** (una tantum o quando cambia) → registri l'assessment.
1. **POST `/pianifica`** con `{problema, azione, cliente_id}` → ricevi il **piano**
   (lista di step CMIOV). *Qui il consulente rivede/aggiusta.* ← checkpoint 1
2. **POST `/esegui`** con `{cliente_id, brief, piano, asset}` → ricevi `dossier`
   (output per fase) e `report` (Quality Gate). *Il consulente valida.* ← checkpoint 2
3. **GET `/clienti/{id}/memoria`** → profilo e storico del cliente.

### Esempio body di /esegui (brief + asset)
```json
{
  "cliente_id": "acme",
  "brief": {
    "problema": "La landing della promo converte poco",
    "azione": "Aumentare i lead dal modulo",
    "domanda_ricerca": "L'attenzione arriva alla CTA?",
    "metrica_target": "Tasso di compilazione modulo",
    "vincoli_specifici": "Test entro 2 settimane, solo mobile",
    "override_profilo": {}
  },
  "piano": [{"fase": "Misura", "prompt_id": 22, "versione": "base", "titolo": ""}],
  "asset": {
    "testo": "Landing della promo estiva",
    "url": "https://esempio.it/promo",
    "immagine_b64": "<base64 dello screenshot>",
    "immagine_media_type": "image/png",
    "pdf_b64": null
  }
}
```

## Prossimi passi (dal piano MVP)

- **Tappa 1→2**: collegare il Router alla mappa problemi reale (`narr_data.PROBLEMI`
  e `CMIOV_MAP`), così il piano usa le sequenze vere invece dei placeholder.
- **Tappa 2**: persistenza memoria su DB; aggiornamento automatico del `contesto`.
- **Tappa 3**: aggiungere come tool una API strumenti (es. Attention Insight) nella fase Misura.
- **Tappa 4**: portare il Router sul **Claude Agent SDK** per la scelta autonoma del percorso.
- **Tappa 5**: autenticazione, rate limiting, eval automatica, hosting UE/GDPR.

## Note di sicurezza e privacy

- La API key sta **solo** lato server (variabile d'ambiente), mai nel frontend.
- La `data/memoria/` contiene dati di clienti: applicare minimizzazione, base
  giuridica, retention e cifratura a riposo prima di un uso reale.
- Il tool di ricerca web è server-side: valutare cosa viene inviato per gli URL dei clienti.
