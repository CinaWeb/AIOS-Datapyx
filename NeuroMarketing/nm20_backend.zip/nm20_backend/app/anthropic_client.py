# -*- coding: utf-8 -*-
"""Wrapper minimale sul Client SDK Anthropic (Messages API).

Per la catena CMIOV usiamo il Client SDK, non l'Agent SDK: la sequenza è
deterministica, quindi non serve un agent loop autonomo (quello è la Tappa 4
del piano MVP). Il tool di ricerca web è server-side: lo passiamo e Anthropic
lo esegue, noi estraiamo solo il testo finale.
"""
from typing import List, Dict, Optional, Any
from anthropic import Anthropic
from .config import Config


def estrai_testo(resp: Any) -> str:
    """Concatena i blocchi di tipo 'text' della risposta, ignorando i blocchi
    tool_use / server_tool_use / risultati di ricerca."""
    parti: List[str] = []
    for blk in getattr(resp, "content", []) or []:
        if getattr(blk, "type", None) == "text":
            parti.append(blk.text)
    return "\n".join(parti).strip()


class ClientLLM:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self._client = Anthropic(api_key=cfg.api_key)

    def chiama(
        self,
        system: str,
        content_blocks: List[Dict],
        usa_web: bool = False,
        model: Optional[str] = None,
        max_tokens: Optional[int] = None,
    ) -> str:
        """Esegue una singola chiamata. content_blocks è la lista di blocchi
        (testo/immagine/document) già pronta per il messaggio 'user'."""
        tools = None
        if usa_web:
            tools = [{
                "type": "web_search_20250305",
                "name": "web_search",
                "max_uses": self.cfg.web_search_max_uses,
            }]
        resp = self._client.messages.create(
            model=model or self.cfg.model,
            max_tokens=max_tokens or self.cfg.max_tokens,
            system=system,
            messages=[{"role": "user", "content": content_blocks}],
            tools=tools,
        )
        return estrai_testo(resp)
