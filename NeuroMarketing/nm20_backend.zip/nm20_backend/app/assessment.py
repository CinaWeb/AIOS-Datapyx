# -*- coding: utf-8 -*-
"""Assessment a due livelli — il punto unico di raccolta dei dati.

Livello 1 — PROFILO AZIENDA (una tantum, vale per tutti i processi):
    dati e esigenze dell'azienda raccolti all'avvio del rapporto. Diventano la
    memoria del cliente e alimentano la fase CONOSCI senza essere ridigitati.

Livello 2 — BRIEF ANALISI (specifico della singola analisi):
    solo il "delta" che cambia da un'analisi all'altra. NON ripete i dati del
    profilo: li eredita tramite cliente_id.

Regole di gestione del dato:
  - unico punto di verità: i campi del profilo stanno SOLO nel ProfiloAzienda;
  - ereditarietà: la singola analisi riusa il profilo + aggiunge il brief;
  - override puntuale: il brief può sovrascrivere un singolo aspetto (es. tono)
    per quella analisi, senza toccare il profilo;
  - tracciabilità: ogni analisi salva lo snapshot del contesto effettivamente usato.
"""
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict, Any


# ---------------- Livello 1: Profilo Azienda (assessment) ----------------
@dataclass
class ProfiloAzienda:
    # --- essenziali (minimo per partire) ---
    nome: str = ""
    settore: str = ""
    modello_business: str = ""          # B2B | B2C | B2B2C | Marketplace | Altro
    prodotti_servizi: str = ""
    pubblico_target: str = ""           # segmenti, buyer persona, job-to-be-done
    obiettivi_marketing: str = ""       # Awareness | Lead | Conversione | Retention | Brand
    kpi_primari: str = ""
    brand_tono: str = ""                # voce, valori, do/don't
    # --- avanzati (opzionali, completano il quadro) ---
    sito_web: str = ""
    mercati: str = ""
    canali: str = ""                    # canali di marketing/vendita
    stack_strumenti: str = ""           # strumenti già in uso (lega allo Stack)
    maturita_analitica: str = ""        # Base | Intermedia | Avanzata
    budget_tipico: str = ""
    competitor: str = ""
    obiezioni_ricorrenti: str = ""
    compliance: str = ""                # GDPR, dati biometrici, settori regolati, claim
    note: str = ""

    # campi che concorrono alla "completezza" dell'assessment essenziale
    _ESSENZIALI = ("nome", "settore", "modello_business", "prodotti_servizi",
                   "pubblico_target", "obiettivi_marketing", "kpi_primari", "brand_tono")

    def completezza(self) -> int:
        """Percentuale di completamento dei campi essenziali (0-100)."""
        compilati = sum(1 for k in self._ESSENZIALI if getattr(self, k, "").strip())
        return round(100 * compilati / len(self._ESSENZIALI))

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def componi_contesto(profilo: ProfiloAzienda, override: Optional[Dict[str, str]] = None) -> str:
    """Trasforma il profilo nel blocco di CONTESTO da iniettare nella fase Conosci.
    `override` permette di sostituire puntualmente un campo per la singola analisi
    (es. un tono diverso) senza modificare il profilo."""
    override = override or {}

    def val(campo: str) -> str:
        return override.get(campo, getattr(profilo, campo, "") or "")

    righe = [
        f"Azienda: {val('nome')} — settore: {val('settore')} ({val('modello_business')})",
        f"Prodotti/servizi: {val('prodotti_servizi')}",
        f"Pubblico target: {val('pubblico_target')}",
        f"Obiettivi di marketing: {val('obiettivi_marketing')} | KPI primari: {val('kpi_primari')}",
        f"Brand e tono: {val('brand_tono')}",
    ]
    # avanzati: inclusi solo se valorizzati, per non appesantire
    avanzati = {
        "Mercati": "mercati", "Canali": "canali", "Stack strumenti": "stack_strumenti",
        "Maturità analitica": "maturita_analitica", "Budget tipico": "budget_tipico",
        "Competitor": "competitor", "Obiezioni ricorrenti": "obiezioni_ricorrenti",
        "Compliance": "compliance",
    }
    for etichetta, campo in avanzati.items():
        if val(campo).strip():
            righe.append(f"{etichetta}: {val(campo)}")
    return "\n".join(r for r in righe if r.split(": ", 1)[-1].strip())


# ---------------- Livello 2: Brief della singola Analisi ----------------
@dataclass
class BriefAnalisi:
    problema: str = ""                  # problema/obiettivo specifico
    azione: str = ""                    # azione/decisione desiderata
    domanda_ricerca: str = ""           # ipotesi o domanda da verificare
    metrica_target: str = ""            # metrica della singola analisi
    vincoli_specifici: str = ""         # deadline, canale, budget del test
    override_profilo: Dict[str, str] = field(default_factory=dict)  # sovrascritture puntuali

    def blocco_brief(self) -> str:
        """Il delta specifico dell'analisi, da affiancare al contesto del profilo."""
        parti = [f"PROBLEMA: {self.problema}", f"AZIONE DESIDERATA: {self.azione}"]
        if self.domanda_ricerca:
            parti.append(f"DOMANDA DI RICERCA / IPOTESI: {self.domanda_ricerca}")
        if self.metrica_target:
            parti.append(f"METRICA TARGET: {self.metrica_target}")
        if self.vincoli_specifici:
            parti.append(f"VINCOLI SPECIFICI: {self.vincoli_specifici}")
        return "\n".join(parti)
