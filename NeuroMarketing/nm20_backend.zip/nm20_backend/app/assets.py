# -*- coding: utf-8 -*-
"""Gestione degli asset multimodali (testo / URL / immagine / PDF).

Trasforma un Asset nei blocchi di contenuto attesi dall'API Anthropic.
- immagine -> blocco 'image' (base64)
- pdf      -> blocco 'document' (base64, application/pdf)
- url      -> nota testuale + attivazione della ricerca web (vedi cmiov.py)
"""
from dataclasses import dataclass
from typing import Optional, List, Dict


@dataclass
class Asset:
    testo: Optional[str] = None
    url: Optional[str] = None
    immagine_b64: Optional[str] = None
    immagine_media_type: str = "image/png"
    pdf_b64: Optional[str] = None

    @property
    def ha_url(self) -> bool:
        return bool(self.url)

    @property
    def ha_file(self) -> bool:
        return bool(self.immagine_b64 or self.pdf_b64)


def costruisci_content(istruzione: str, asset: Optional[Asset]) -> List[Dict]:
    """Costruisce la lista di blocchi 'content' per il messaggio user.
    L'istruzione (testo della fase + prompt) va sempre per ultima, dopo i media."""
    blocks: List[Dict] = []

    if asset and asset.immagine_b64:
        blocks.append({
            "type": "image",
            "source": {"type": "base64", "media_type": asset.immagine_media_type, "data": asset.immagine_b64},
        })
    if asset and asset.pdf_b64:
        blocks.append({
            "type": "document",
            "source": {"type": "base64", "media_type": "application/pdf", "data": asset.pdf_b64},
        })

    testo = istruzione
    extra: List[str] = []
    if asset and asset.testo:
        extra.append(f"TESTO/DESCRIZIONE DELL'ASSET:\n{asset.testo}")
    if asset and asset.url:
        extra.append(
            f"URL DA ANALIZZARE: {asset.url}\n"
            "(usa la ricerca web per recuperarne i contenuti rilevanti prima di rispondere)"
        )
    if extra:
        testo = istruzione + "\n\n" + "\n\n".join(extra)

    blocks.append({"type": "text", "text": testo})
    return blocks
