# -*- coding: utf-8 -*-
"""Orchestratore della catena CMIOV.

Esegue il piano (lista di Step) fase per fase, accumulando un 'dossier':
l'output di ogni fase entra nel contesto della successiva.

Dati a due livelli (niente duplicazione):
  - il CONTESTO del cliente arriva dal PROFILO AZIENDA (assessment, una tantum);
  - il BRIEF porta solo il delta specifico dell'analisi.
La fase CONOSCI parte già dal profilo, quindi non si richiedono di nuovo i dati aziendali.
"""
from typing import List, Optional, Dict, Any

from .config import Config
from .router import Step
from .assets import Asset, costruisci_content
from .library import Libreria
from .anthropic_client import ClientLLM
from .memory import MemoriaCliente
from .assessment import BriefAnalisi, componi_contesto


SYSTEM_BASE = (
    "Sei un analista esperto di NeuroMarketing 2.0 che lavora secondo il loop CMIOV "
    "(Conosci, Misura, Interpreta, Ottimizza, Verifica). Ragioni con rigore comportamentale, "
    "distingui sempre le osservazioni dalle raccomandazioni, eviti affermazioni non supportate "
    "e rispondi in italiano, in modo conciso e operativo."
)

ISTRUZIONI_FASE: Dict[str, str] = {
    "Conosci":    "FASE CONOSCI. Parti dal profilo aziendale fornito e mettine a fuoco gli elementi rilevanti per il problema.",
    "Misura":     "FASE MISURA. Esegui l'audit dell'asset: attenzione, fiducia, carico cognitivo, punti di friction.",
    "Interpreta": "FASE INTERPRETA. Triangola i segnali, individua i gap comportamentali prioritari e le cause.",
    "Ottimizza":  "FASE OTTIMIZZA. Proponi varianti concrete dell'asset con il razionale comportamentale.",
    "Verifica":   "FASE VERIFICA. Definisci A/B test e metriche di verifica per misurare il miglioramento.",
}


class Orchestratore:
    def __init__(self, cfg: Config, libreria: Libreria, client: ClientLLM, memoria: MemoriaCliente):
        self.cfg = cfg
        self.libreria = libreria
        self.client = client
        self.memoria = memoria

    def esegui(
        self,
        brief: BriefAnalisi,
        cliente_id: str,
        piano: List[Step],
        asset: Optional[Asset] = None,
    ) -> Dict[str, Any]:
        """Esegue la catena CMIOV. Restituisce dossier + lo snapshot di contesto usato."""
        # CONTESTO dal profilo azienda (assessment), con eventuali override del brief
        profilo = self.memoria.get_profilo(cliente_id)
        contesto = componi_contesto(profilo, brief.override_profilo)
        blocco_brief = brief.blocco_brief()

        dossier: List[Dict[str, Any]] = []
        for step in piano:
            prompt_scheda = self.libreria.prompt(step.prompt_id, step.versione)
            istruzione = self._componi_istruzione(step, contesto, blocco_brief, prompt_scheda, dossier)

            asset_fase = asset if step.fase in ("Conosci", "Misura") else None
            usa_web = bool(asset and asset.ha_url) and step.fase in ("Conosci", "Misura")

            content = costruisci_content(istruzione, asset_fase)
            output = self.client.chiama(SYSTEM_BASE, content, usa_web=usa_web)

            dossier.append({
                "fase": step.fase,
                "scheda": step.prompt_id,
                "titolo": self.libreria.titolo(step.prompt_id),
                "output": output,
            })

        return {"dossier": dossier, "contesto_snapshot": contesto}

    def _componi_istruzione(
        self,
        step: Step,
        contesto: str,
        blocco_brief: str,
        prompt_scheda: str,
        dossier: List[Dict[str, Any]],
    ) -> str:
        parti: List[str] = [ISTRUZIONI_FASE.get(step.fase, "")]
        if contesto:
            parti.append(f"PROFILO AZIENDA (assessment):\n{contesto}")
        parti.append(f"BRIEF DELL'ANALISI:\n{blocco_brief}")
        if dossier:
            sintesi = "\n\n".join(
                f"[{d['fase']} \u2014 {d['titolo']}]\n{d['output']}" for d in dossier
            )
            parti.append(f"RISULTATI DELLE FASI PRECEDENTI:\n{sintesi}")
        if prompt_scheda:
            parti.append(f"PROMPT OPERATIVO DA APPLICARE:\n{prompt_scheda}")
        return "\n\n".join(p for p in parti if p)
