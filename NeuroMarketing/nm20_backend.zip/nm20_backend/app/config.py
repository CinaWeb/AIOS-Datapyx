# -*- coding: utf-8 -*-
"""Configurazione del backend. La API key viene letta SOLO da variabile d'ambiente:
non deve mai stare nel codice né nel frontend."""
import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv  # comodità su Windows: carica un file .env se presente
    load_dotenv()
except Exception:
    pass


@dataclass
class Config:
    api_key: str
    model: str = "claude-sonnet-4-6"             # modello per le fasi CMIOV
    model_quality_gate: str = "claude-sonnet-4-6"  # modello per il quality gate
    max_tokens: int = 4096
    lib_data_path: str = "./data/lib_data.json"  # la tua libreria 111 prompt
    memoria_dir: str = "./data/memoria"          # memoria per cliente (stub su file)
    audit_log: str = "./data/audit.log.jsonl"    # log/audit append-only
    web_search_max_uses: int = 5

    @classmethod
    def from_env(cls) -> "Config":
        key = os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY non impostata. Su Windows: set ANTHROPIC_API_KEY=sk-ant-... "
                "oppure crea un file .env (vedi .env.example)."
            )
        return cls(
            api_key=key,
            model=os.environ.get("NM20_MODEL", "claude-sonnet-4-6"),
            model_quality_gate=os.environ.get("NM20_MODEL_QC", "claude-sonnet-4-6"),
            max_tokens=int(os.environ.get("NM20_MAX_TOKENS", "4096")),
            lib_data_path=os.environ.get("LIB_DATA_PATH", "./data/lib_data.json"),
            memoria_dir=os.environ.get("NM20_MEMORIA_DIR", "./data/memoria"),
            audit_log=os.environ.get("NM20_AUDIT_LOG", "./data/audit.log.jsonl"),
            web_search_max_uses=int(os.environ.get("NM20_WEB_MAX_USES", "5")),
        )
