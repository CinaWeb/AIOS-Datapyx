# -*- coding: utf-8 -*-
"""Caricamento della libreria dei 111 prompt (lib_data.json).

Formato atteso di ogni scheda (coerente col progetto):
  {"num": 1, "titolo": "...", "base": "...", "avanzato": "...", "meta": {...}, "nota": "..."}
"""
import json
import os
from typing import Dict, Optional


class Libreria:
    def __init__(self, path: str):
        self.schede: Dict[int, dict] = {}
        risolto = self._risolvi(path)
        if risolto and os.path.exists(risolto):
            with open(risolto, encoding="utf-8") as f:
                data = json.load(f)
            for s in data:
                self.schede[int(s["num"])] = s
            print(f"[libreria] caricate {len(self.schede)} schede da {risolto}")
        else:
            print(f"[libreria][ATTENZIONE] file non trovato: {path}. "
                  "Imposta LIB_DATA_PATH sul tuo lib_data.json reale.")

    @staticmethod
    def _risolvi(path: str) -> Optional[str]:
        """Se il file indicato non esiste, prova il sample nella stessa cartella."""
        if os.path.exists(path):
            return path
        sample = os.path.join(os.path.dirname(path) or ".", "lib_data.sample.json")
        return sample if os.path.exists(sample) else path

    def get(self, num: int) -> Optional[dict]:
        return self.schede.get(int(num))

    def prompt(self, num: int, versione: str = "base") -> str:
        s = self.get(num)
        if not s:
            return ""
        return s.get("avanzato", "") if versione == "avanzato" else s.get("base", "")

    def titolo(self, num: int) -> str:
        s = self.get(num)
        return s["titolo"] if s else f"scheda {num}"
