# -*- coding: utf-8 -*-
"""API del backend orchestratore.

Dati a due livelli:
  - ASSESSMENT (profilo azienda, una tantum):  /clienti/{id}/profilo  (GET, PUT)
  - BRIEF (singola analisi):                    nel corpo di /esegui

Flusso con i due checkpoint umani del blueprint:
  POST /pianifica  -> il Router propone il piano (il consulente lo rivede)
  POST /esegui     -> esegue la catena CMIOV sul piano confermato + Quality Gate

Avvio:  uvicorn app.main:app --reload
"""
import json
import datetime
from typing import List, Optional, Dict

from fastapi import FastAPI
from pydantic import BaseModel

from .config import Config
from .library import Libreria
from .anthropic_client import ClientLLM
from .memory import MemoriaCliente
from .assets import Asset
from .assessment import ProfiloAzienda, BriefAnalisi
from .router import pianifica, Step
from .cmiov import Orchestratore
from .quality_gate import applica_quality_gate

# --- inizializzazione (una sola volta) ---
cfg = Config.from_env()
libreria = Libreria(cfg.lib_data_path)
client = ClientLLM(cfg)
memoria = MemoriaCliente(cfg.memoria_dir)
orch = Orchestratore(cfg, libreria, client, memoria)

app = FastAPI(title="NeuroMarketing 2.0 Advisor — Backend Orchestratore")


# --- modelli I/O ---
class ProfiloIn(BaseModel):
    # Livello 1 — assessment azienda. Tutti i campi opzionali: compilazione progressiva.
    nome: str = ""
    settore: str = ""
    modello_business: str = ""
    prodotti_servizi: str = ""
    pubblico_target: str = ""
    obiettivi_marketing: str = ""
    kpi_primari: str = ""
    brand_tono: str = ""
    sito_web: str = ""
    mercati: str = ""
    canali: str = ""
    stack_strumenti: str = ""
    maturita_analitica: str = ""
    budget_tipico: str = ""
    competitor: str = ""
    obiezioni_ricorrenti: str = ""
    compliance: str = ""
    note: str = ""


class BriefIn(BaseModel):
    # Livello 2 — solo il delta specifico dell'analisi (eredita il profilo via cliente_id)
    problema: str
    azione: str
    domanda_ricerca: str = ""
    metrica_target: str = ""
    vincoli_specifici: str = ""
    override_profilo: Dict[str, str] = {}


class AssetIn(BaseModel):
    testo: Optional[str] = None
    url: Optional[str] = None
    immagine_b64: Optional[str] = None
    immagine_media_type: str = "image/png"
    pdf_b64: Optional[str] = None


class PianoIn(BaseModel):
    problema: str
    azione: str
    cliente_id: str = "anonimo"
    prompt_ids: Optional[List[int]] = None


class StepOut(BaseModel):
    fase: str
    prompt_id: int
    versione: str = "base"
    titolo: str = ""


class EseguiIn(BaseModel):
    cliente_id: str = "anonimo"
    brief: BriefIn
    piano: List[StepOut]
    asset: Optional[AssetIn] = None


# --- endpoint: salute ---
@app.get("/salute")
def salute():
    return {"stato": "ok", "schede": len(libreria.schede), "modello": cfg.model}


# --- endpoint: ASSESSMENT (profilo azienda) ---
@app.get("/clienti/{cliente_id}/profilo")
def get_profilo(cliente_id: str):
    p = memoria.get_profilo(cliente_id)
    return {"cliente_id": cliente_id, "profilo": p.to_dict(), "completezza": p.completezza()}


@app.put("/clienti/{cliente_id}/profilo")
def put_profilo(cliente_id: str, req: ProfiloIn):
    """Crea/aggiorna l'assessment dell'azienda (una tantum, riusato in ogni analisi)."""
    profilo = ProfiloAzienda(**req.model_dump())
    return memoria.salva_profilo(cliente_id, profilo)


# --- endpoint: PIANIFICA (checkpoint 1) ---
@app.post("/pianifica", response_model=List[StepOut])
def endpoint_pianifica(req: PianoIn):
    piano = pianifica(req.problema, req.prompt_ids)
    return [
        StepOut(fase=s.fase, prompt_id=s.prompt_id, versione=s.versione,
                titolo=libreria.titolo(s.prompt_id))
        for s in piano
    ]


# --- endpoint: ESEGUI ---
@app.post("/esegui")
def endpoint_esegui(req: EseguiIn):
    piano = [Step(fase=s.fase, prompt_id=s.prompt_id, versione=s.versione) for s in req.piano]
    brief = BriefAnalisi(
        problema=req.brief.problema,
        azione=req.brief.azione,
        domanda_ricerca=req.brief.domanda_ricerca,
        metrica_target=req.brief.metrica_target,
        vincoli_specifici=req.brief.vincoli_specifici,
        override_profilo=req.brief.override_profilo or {},
    )
    asset = None
    if req.asset:
        asset = Asset(
            testo=req.asset.testo, url=req.asset.url,
            immagine_b64=req.asset.immagine_b64,
            immagine_media_type=req.asset.immagine_media_type,
            pdf_b64=req.asset.pdf_b64,
        )

    risultato = orch.esegui(brief, req.cliente_id, piano, asset)
    dossier = risultato["dossier"]
    report = applica_quality_gate(client, cfg, brief.problema, brief.azione, dossier)

    voce = {
        "data": datetime.datetime.utcnow().isoformat(),
        "problema": brief.problema,
        "azione": brief.azione,
        "metrica_target": brief.metrica_target,
        "contesto_snapshot": risultato["contesto_snapshot"],
        "report": report,
    }
    memoria.salva_analisi(req.cliente_id, voce)
    _audit("esegui", {"cliente_id": req.cliente_id, "n_step": len(piano)})

    return {"dossier": dossier, "report": report, "contesto_snapshot": risultato["contesto_snapshot"]}


@app.get("/clienti/{cliente_id}/memoria")
def endpoint_memoria(cliente_id: str):
    return memoria.get(cliente_id)


def _audit(evento: str, dati: dict) -> None:
    try:
        with open(cfg.audit_log, "a", encoding="utf-8") as f:
            f.write(json.dumps(
                {"ts": datetime.datetime.utcnow().isoformat(), "evento": evento, **dati},
                ensure_ascii=False) + "\n")
    except Exception:
        pass
