# -*- coding: utf-8 -*-
"""Memoria per cliente/progetto (stub su file JSON).

Conserva il PROFILO AZIENDA (assessment, Livello 1) e lo storico delle analisi.
Il profilo è il punto unico di verità dei dati aziendali: si compila una volta
e si riusa in tutte le analisi.

ATTENZIONE GDPR: qui si conservano dati di clienti. Applicare minimizzazione,
base giuridica, retention e cifratura a riposo prima dell'uso reale.
"""
import os
import json
from typing import Dict, Any
from .assessment import ProfiloAzienda


class MemoriaCliente:
    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        os.makedirs(base_dir, exist_ok=True)

    def _path(self, cliente_id: str) -> str:
        safe = "".join(c for c in cliente_id if c.isalnum() or c in ("-", "_")) or "anonimo"
        return os.path.join(self.base_dir, f"{safe}.json")

    def get(self, cliente_id: str) -> Dict[str, Any]:
        p = self._path(cliente_id)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                return json.load(f)
        return {"cliente_id": cliente_id, "profilo": {}, "storico": []}

    # --- profilo azienda (assessment, Livello 1) ---
    def get_profilo(self, cliente_id: str) -> ProfiloAzienda:
        dati = self.get(cliente_id).get("profilo", {}) or {}
        campi = {k: v for k, v in dati.items() if k in ProfiloAzienda.__dataclass_fields__}
        return ProfiloAzienda(**campi)

    def salva_profilo(self, cliente_id: str, profilo: ProfiloAzienda) -> Dict[str, Any]:
        d = self.get(cliente_id)
        d["profilo"] = profilo.to_dict()
        self._scrivi(cliente_id, d)
        return {"cliente_id": cliente_id, "completezza": profilo.completezza()}

    # --- storico analisi ---
    def salva_analisi(self, cliente_id: str, voce: Dict[str, Any]) -> None:
        d = self.get(cliente_id)
        d.setdefault("storico", []).append(voce)
        self._scrivi(cliente_id, d)

    def _scrivi(self, cliente_id: str, d: Dict[str, Any]) -> None:
        with open(self._path(cliente_id), "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=2)
