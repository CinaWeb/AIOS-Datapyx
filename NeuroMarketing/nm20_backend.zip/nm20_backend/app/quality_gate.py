# -*- coding: utf-8 -*-
"""Quality Gate: l'ultimo passo della catena.

Rilegge l'intero dossier delle fasi CMIOV e produce il report finale,
separando fatti e ipotesi, segnalando i rischi e traducendo tutto in azioni
con metrica di verifica. Sostituisce/raffina il 'prompt QC' del progetto.
"""
from typing import List, Dict, Any
from .config import Config
from .anthropic_client import ClientLLM


PROMPT_QC = (
    "Sei il controllo qualità di un'analisi di NeuroMarketing 2.0. Rileggi il dossier "
    "delle fasi CMIOV e produci il REPORT FINALE strutturato in queste sezioni:\n"
    "1) Sintesi esecutiva (3-5 righe);\n"
    "2) Fatti osservati (solo ciò che è supportato dall'asset o dai dati);\n"
    "3) Ipotesi e assunzioni (chiaramente separate dai fatti);\n"
    "4) Rischi e limiti dell'analisi;\n"
    "5) Raccomandazioni operative: ciascuna come azione concreta con la metrica con cui verificarla.\n"
    "Segnala esplicitamente ogni affermazione non supportata e ogni punto in cui servono dati reali "
    "(es. eye-tracking o test comportamentale). Rispondi in italiano."
)


def applica_quality_gate(
    client: ClientLLM,
    cfg: Config,
    problema: str,
    azione: str,
    dossier: List[Dict[str, Any]],
) -> str:
    testo_dossier = "\n\n".join(
        f"### {d['fase']} \u2014 {d['titolo']} (scheda {d['scheda']})\n{d['output']}"
        for d in dossier
    )
    istruzione = (
        f"PROBLEMA: {problema}\n"
        f"AZIONE DESIDERATA: {azione}\n\n"
        f"DOSSIER DELLE FASI CMIOV:\n{testo_dossier}"
    )
    content = [{"type": "text", "text": istruzione}]
    return client.chiama(PROMPT_QC, content, model=cfg.model_quality_gate)
