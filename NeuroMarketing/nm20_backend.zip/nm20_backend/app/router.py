# -*- coding: utf-8 -*-
"""Router (orchestratore): dal problema al piano di analisi.

In questa versione il Router è DETERMINISTICO (euristica + mappa problemi):
sufficiente per l'MVP e molto più economico di un agente autonomo.

TODO (Tappa 4 del piano MVP):
  - collegare la mappa reale problema->prompt (narr_data.PROBLEMI) e
    la mappa fase->prompt (narr_data.CMIOV_MAP, Appendice D);
  - opzionale: classificazione del problema via LLM quando l'euristica non basta;
  - portare il Router sul Claude Agent SDK per la scelta autonoma del percorso.
"""
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Step:
    """Un passo della catena: quale fase CMIOV, quale scheda della libreria, quale versione."""
    fase: str            # Conosci | Misura | Interpreta | Ottimizza | Verifica
    prompt_id: int
    versione: str = "base"   # base | avanzato


# Sequenze esemplificative (placeholder). Gli ID vanno allineati alla tua libreria reale.
# Ogni sequenza copre il loop CMIOV: Conosci -> Misura -> Interpreta -> Ottimizza -> Verifica.
SEQUENZE: dict = {
    "default": [
        Step("Conosci", 7),
        Step("Misura", 22),
        Step("Misura", 46),
        Step("Interpreta", 2),
        Step("Ottimizza", 1),
        Step("Verifica", 11),
    ],
    # parole chiave -> sequenza dedicata (esempi)
    "fiducia": [
        Step("Conosci", 7), Step("Misura", 35), Step("Interpreta", 5),
        Step("Ottimizza", 4), Step("Verifica", 17),
    ],
    "prezzo": [
        Step("Conosci", 12), Step("Misura", 33), Step("Interpreta", 31),
        Step("Ottimizza", 27), Step("Verifica", 19),
    ],
    "attenzione": [
        Step("Conosci", 7), Step("Misura", 22), Step("Interpreta", 3),
        Step("Ottimizza", 2), Step("Verifica", 11),
    ],
}

# Mappa di default fase per uno prompt scelto manualmente (fallback grezzo).
_FASE_DI_DEFAULT = "Misura"


def pianifica(problema: str, prompt_ids: Optional[List[int]] = None) -> List[Step]:
    """Produce il piano di analisi (lista di Step).

    - Se il consulente ha già scelto i prompt (prompt_ids), li rispetta.
    - Altrimenti applica un'euristica per parola chiave; in mancanza di match,
      usa la sequenza 'default'.
    """
    if prompt_ids:
        # TODO: dedurre la fase corretta per ciascun prompt dalla CMIOV_MAP reale.
        return [Step(fase=_FASE_DI_DEFAULT, prompt_id=int(p)) for p in prompt_ids]

    p = (problema or "").lower()
    for chiave, seq in SEQUENZE.items():
        if chiave != "default" and chiave in p:
            return list(seq)
    return list(SEQUENZE["default"])
