# Prompt da incollare nel builder AI di Base44

Copia tutto il blocco seguente come primo messaggio nel builder di Base44 per
generare l'ossatura dell'app (entità, pagine, navigazione). Poi completa con le
entità precise, la funzione backend e l'import dei dati (vedi README).

---

Crea un'applicazione web in italiano chiamata "NeuroMarketing 2.0 Advisor", uno
strumento di consulenza che analizza asset di marketing con un framework
comportamentale chiamato CMIOV (Conosci, Misura, Interpreta, Ottimizza, Verifica).

UTENTI: un consulente di marketing che gestisce più clienti/aziende.

PRINCIPIO DEI DATI A DUE LIVELLI (importante, niente duplicazione):
- Livello 1 = ASSESSMENT dell'azienda: dati ed esigenze raccolti UNA TANTUM, validi
  per tutte le analisi (entità ProfiloAzienda). È la memoria del cliente.
- Livello 2 = BRIEF della singola analisi: solo ciò che cambia da un'analisi all'altra
  (entità Analisi). Eredita i dati aziendali dal ProfiloAzienda e NON li ripete.

ENTITÀ (database):
1. ProfiloAzienda — assessment dell'azienda (una tantum). Campi essenziali: nome,
   settore, modello_business (B2B/B2C/B2B2C/Marketplace/Altro), prodotti_servizi,
   pubblico_target, obiettivi_marketing, kpi_primari, brand_tono. Campi avanzati
   (opzionali): sito_web, mercati, canali, stack_strumenti, maturita_analitica
   (Base/Intermedia/Avanzata), budget_tipico, competitor, obiezioni_ricorrenti,
   compliance, note.
2. Analisi — la singola analisi (brief). Campi: cliente_id (riferimento a
   ProfiloAzienda), titolo, problema, azione, domanda_ricerca, metrica_target,
   vincoli_specifici, override_profilo (oggetto), asset_url, piano (lista),
   dossier (lista), contesto_snapshot, report, stato (pianificata/eseguita/validata).
3. PromptScheda — libreria di prompt. Campi: num, titolo, cap, fase
   (Conosci/Misura/Interpreta/Ottimizza/Verifica), base (testo lungo),
   avanzato (testo lungo), meta (oggetto), nota.

PAGINE:
- "Assessment azienda": form per creare/aggiornare il ProfiloAzienda, diviso in
  "Dati essenziali" e "Avanzati (opzionali)", con un indicatore di completezza.
  Si compila una volta e si riusa. NON va richiesto di nuovo nelle analisi.
- "Nuova analisi": si sceglie prima l'azienda (ProfiloAzienda); i suoi dati restano
  visibili in sola lettura come contesto ereditato. Poi si compila SOLO il brief:
  problema, azione, domanda_ricerca, metrica_target, vincoli_specifici, e il blocco
  asset (testo/descrizione, URL, upload immagine, upload PDF). Un pulsante
  "Proponi piano" mostra la sequenza di step CMIOV (il Router), modificabile.
  "Esegui analisi" lancia la catena.
- "Risultato": dossier fase per fase (Conosci → Verifica) in sezioni collassabili e,
  in evidenza, il report finale del Quality Gate; pulsanti per copiare il report e
  segnare l'analisi "validata".
- "Aziende": elenco dei ProfiloAzienda con la loro completezza e lo storico delle analisi.
- "Libreria": elenco filtrabile delle PromptScheda (ricerca per titolo, filtro per
  capitolo e per fase); aprendo una scheda si vedono metadati, prompt base e avanzato.

STILE: professionale e sobrio, palette blu/navy, molto chiaro, adatto a un contesto
consulenziale B2B.

LOGICA AI: l'esecuzione gira in una funzione backend che, per ogni step del piano,
chiama il modello LLM passando il CONTESTO ereditato dal ProfiloAzienda, il BRIEF
specifico, il prompt della scheda, l'eventuale asset (URL via ricerca web,
immagine/PDF come allegati) e i risultati delle fasi precedenti; alla fine un passo
di "Quality Gate" produce il report. Modello: Claude (claude_sonnet_4_6).

Non inventare i contenuti dei prompt: verranno importati nell'entità PromptScheda.
