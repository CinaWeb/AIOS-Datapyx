# NeuroMarketing 2.0 Advisor — Kit di costruzione per Base44

Tutto il necessario per costruire l'app su **Base44**, coerente con il blueprint
(Router → catena CMIOV → Quality Gate), con gestione asset (testo / URL / immagine /
PDF), **assessment dell'azienda** e memoria per cliente.

> Nota: il kit si assembla sul tuo account Base44 (app.base44.com). Da una chat non è
> possibile pubblicare direttamente sul tuo workspace: qui trovi i pezzi pronti e i passi.

## Dati a due livelli (assessment + brief) — niente duplicazione

- **Livello 1 — ProfiloAzienda (assessment, una tantum):** i dati e le esigenze
  dell'azienda, validi per tutte le analisi. Si compila una volta (pagina "Assessment
  azienda") e diventa la memoria del cliente, alimentando la fase Conosci.
- **Livello 2 — Analisi (brief specifico):** solo ciò che cambia ogni volta (problema,
  azione, domanda di ricerca, metrica target, vincoli). **Eredita** il profilo via
  `cliente_id` e non ne ripete i campi; può fare un `override_profilo` puntuale per la
  singola analisi senza modificare il profilo. Ogni analisi salva il `contesto_snapshot`
  effettivamente usato, per tracciabilità.

Punto unico di verità = ProfiloAzienda. Questo migliora usabilità (compili una volta,
riusi sempre) e gestione del dato (niente duplicati, override controllati, storico).

## Contenuto del kit

```
nm20_base44_kit/
├─ 1_PROMPT_BASE44.md          # prompt da incollare nel builder AI di Base44
├─ entities/
│  ├─ ProfiloAzienda.json      # entità assessment (Livello 1)
│  ├─ Analisi.json             # entità analisi/brief (Livello 2, eredita il profilo)
│  └─ PromptScheda.json        # entità libreria 111 prompt
├─ functions/
│  ├─ orchestratoreCMIOV.js    # backend: contesto-da-profilo + brief + catena + quality gate
│  └─ pianifica.js             # router: problema -> sequenza di step CMIOV
└─ data/
   └─ PromptSchede_import.json # le tue 111 schede pronte da importare
```

## Perché Base44 calza bene qui

- **InvokeLLM** integrato gestisce testo, allegati file, analisi immagini e ricerca web:
  copre i quattro tipi di asset del framework e supporta il modello `claude_sonnet_4_6`.
- **Entità + memoria**: il ProfiloAzienda persiste tra le sessioni (assessment riusabile).
- **Backend functions**: la catena CMIOV gira lato server, con la chiave gestita dalla
  piattaforma (non nel browser).

## Passi di assemblaggio

1. **Genera l'ossatura.** Crea una nuova app su Base44 e incolla come primo messaggio
   il contenuto di `1_PROMPT_BASE44.md`.
2. **Allinea le entità** ai file in `entities/` (ProfiloAzienda, Analisi, PromptScheda).
3. **Importa la libreria.** Nell'entità PromptScheda carica `data/PromptSchede_import.json`
   (111 schede).
4. **Compila un assessment** di prova nella pagina "Assessment azienda" (un ProfiloAzienda).
5. **Aggiungi la funzione backend** `orchestratoreCMIOV` con la logica di
   `functions/orchestratoreCMIOV.js` e collegala al pulsante "Esegui analisi".
6. **Aggiungi il Router** (`functions/pianifica.js`) al pulsante "Proponi piano".
7. **Imposta il modello** Claude (`claude_sonnet_4_6`) nelle impostazioni AI dell'app.
8. **Asset.** Usa l'upload file di Base44 (Core.UploadFile) per immagine/PDF e passa gli
   URL in `asset.file_urls`; l'URL testuale va in `asset.url` (attiva la ricerca web).

## Flusso d'uso (i due checkpoint del blueprint)

0. **Assessment** dell'azienda (una tantum o quando cambia) → ProfiloAzienda.
1. Scegli l'azienda, compili **solo il brief** + asset → "Proponi piano" (Router).
   → Il consulente rivede il piano. ← checkpoint 1
2. **Esegui analisi** → catena CMIOV + Quality Gate, salva l'Analisi (con
   contesto_snapshot) e mostra dossier + report. → Il consulente valida. ← checkpoint 2
3. Le aziende e lo storico delle analisi restano consultabili.

## Mappatura con il backend Python

Trasposizione su Base44 dello scheletro `nm20_backend`:
`ProfiloAzienda`/`Analisi` ↔ `assessment.py` + `memory.py`; `orchestratoreCMIOV.js` ↔
`cmiov.py` + `quality_gate.py`; `pianifica.js` ↔ `router.py`; `InvokeLLM` ↔
`anthropic_client.py`. Stessa logica, piattaforma diversa.

## Prossimo passo consigliato

Sostituire le sequenze placeholder in `pianifica.js` con la tua mappa reale
problema→prompt (PROBLEMI/CMIOV_MAP) e assegnare il campo `fase` alle schede.
