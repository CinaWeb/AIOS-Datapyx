// orchestratoreCMIOV — Funzione backend Base44
// Esegue la catena CMIOV usando i dati a DUE LIVELLI (niente duplicazione):
//   - CONTESTO dal ProfiloAzienda (assessment, una tantum) -> fase Conosci;
//   - BRIEF specifico della singola analisi -> il delta che cambia ogni volta.
// Gestisce gli asset (testo / URL / immagine / PDF) e applica il Quality Gate.
//
// INPUT (JSON):
//  { cliente_id,
//    brief: { problema, azione, domanda_ricerca, metrica_target, vincoli_specifici, override_profilo },
//    piano: [{fase, prompt_num, versione}],
//    asset: { testo, url, file_urls:[] } }
// OUTPUT: { dossier:[...], report, contesto_snapshot, analisi_id }

const MODELLO = "claude_sonnet_4_6";

const SYSTEM_BASE =
  "Sei un analista esperto di NeuroMarketing 2.0 che lavora secondo il loop CMIOV " +
  "(Conosci, Misura, Interpreta, Ottimizza, Verifica). Distingui sempre osservazioni " +
  "e raccomandazioni, eviti affermazioni non supportate e rispondi in italiano.";

const ISTRUZIONI_FASE = {
  Conosci:    "FASE CONOSCI. Parti dal profilo aziendale e mettine a fuoco gli elementi rilevanti per il problema.",
  Misura:     "FASE MISURA. Esegui l'audit dell'asset: attenzione, fiducia, carico cognitivo, friction.",
  Interpreta: "FASE INTERPRETA. Triangola i segnali, individua i gap comportamentali prioritari.",
  Ottimizza:  "FASE OTTIMIZZA. Proponi varianti concrete dell'asset con il razionale comportamentale.",
  Verifica:   "FASE VERIFICA. Definisci A/B test e metriche di verifica.",
};

const PROMPT_QC =
  "Sei il controllo qualita di un'analisi di NeuroMarketing 2.0. Rileggi il dossier e produci il " +
  "REPORT FINALE in: 1) Sintesi esecutiva; 2) Fatti osservati; 3) Ipotesi e assunzioni (separate); " +
  "4) Rischi e limiti; 5) Raccomandazioni operative, ciascuna come azione con la metrica per verificarla. " +
  "Segnala ogni affermazione non supportata e dove servono dati reali. Rispondi in italiano.";

// Compone il blocco CONTESTO dal profilo (con override puntuali del brief).
function componiContesto(profilo, override) {
  if (!profilo) return "";
  const v = (campo) => (override && override[campo] != null ? override[campo] : (profilo[campo] || ""));
  const righe = [
    `Azienda: ${v("nome")} - settore: ${v("settore")} (${v("modello_business")})`,
    `Prodotti/servizi: ${v("prodotti_servizi")}`,
    `Pubblico target: ${v("pubblico_target")}`,
    `Obiettivi: ${v("obiettivi_marketing")} | KPI: ${v("kpi_primari")}`,
    `Brand e tono: ${v("brand_tono")}`,
  ];
  const avanzati = { Mercati: "mercati", Canali: "canali", "Stack strumenti": "stack_strumenti",
    "Maturita analitica": "maturita_analitica", "Budget": "budget_tipico", Competitor: "competitor",
    "Obiezioni ricorrenti": "obiezioni_ricorrenti", Compliance: "compliance" };
  for (const [et, campo] of Object.entries(avanzati)) {
    if ((v(campo) || "").trim()) righe.push(`${et}: ${v(campo)}`);
  }
  return righe.filter((r) => r.split(": ").slice(1).join(": ").trim()).join("\n");
}

function blocoBrief(brief) {
  const parti = [`PROBLEMA: ${brief.problema}`, `AZIONE DESIDERATA: ${brief.azione}`];
  if (brief.domanda_ricerca)   parti.push(`DOMANDA DI RICERCA / IPOTESI: ${brief.domanda_ricerca}`);
  if (brief.metrica_target)    parti.push(`METRICA TARGET: ${brief.metrica_target}`);
  if (brief.vincoli_specifici) parti.push(`VINCOLI SPECIFICI: ${brief.vincoli_specifici}`);
  return parti.join("\n");
}

export async function runCMIOV(base44, input) {
  const { cliente_id, brief = {}, piano = [], asset = {} } = input;

  // 1) CONTESTO dal ProfiloAzienda (assessment) - niente ridigitazione dei dati aziendali
  let profilo = null;
  if (cliente_id) {
    try { profilo = await base44.entities.ProfiloAzienda.get(cliente_id); } catch (_) {}
  }
  const contesto = componiContesto(profilo, brief.override_profilo);
  const brief_txt = blocoBrief(brief);

  // 2) schede del piano (indicizzate per num)
  const nums = [...new Set(piano.map((s) => s.prompt_num))];
  const schede = {};
  for (const n of nums) {
    const res = await base44.entities.PromptScheda.filter({ num: n });
    if (res && res.length) schede[n] = res[0];
  }

  // 3) catena CMIOV
  const dossier = [];
  for (const step of piano) {
    const scheda = schede[step.prompt_num] || {};
    const promptScheda = step.versione === "avanzato" ? (scheda.avanzato || "") : (scheda.base || "");

    const parti = [ISTRUZIONI_FASE[step.fase] || ""];
    if (contesto) parti.push(`PROFILO AZIENDA (assessment):\n${contesto}`);
    parti.push(`BRIEF DELL'ANALISI:\n${brief_txt}`);
    if (dossier.length) {
      parti.push("RISULTATI DELLE FASI PRECEDENTI:\n" +
        dossier.map((d) => `[${d.fase} - ${d.titolo}]\n${d.output}`).join("\n\n"));
    }
    if (promptScheda) parti.push(`PROMPT OPERATIVO DA APPLICARE:\n${promptScheda}`);
    const istruzione = parti.filter(Boolean).join("\n\n");

    const usaAsset = step.fase === "Conosci" || step.fase === "Misura";
    const out = await base44.integrations.Core.InvokeLLM({
      prompt: SYSTEM_BASE + "\n\n" + istruzione,
      model: MODELLO,
      add_context_from_internet: usaAsset && !!asset.url,
      file_urls: usaAsset ? (asset.file_urls || []) : [],
    });

    dossier.push({
      fase: step.fase, scheda: step.prompt_num,
      titolo: scheda.titolo || ("scheda " + step.prompt_num),
      output: typeof out === "string" ? out : JSON.stringify(out),
    });
  }

  // 4) Quality Gate
  const testoDossier = dossier.map((d) => `### ${d.fase} - ${d.titolo} (scheda ${d.scheda})\n${d.output}`).join("\n\n");
  const report = await base44.integrations.Core.InvokeLLM({
    prompt: PROMPT_QC + `\n\nPROBLEMA: ${brief.problema}\nAZIONE: ${brief.azione}\n\nDOSSIER:\n${testoDossier}`,
    model: MODELLO,
  });

  // 5) salvataggio Analisi (con snapshot del contesto usato, per tracciabilita)
  let analisi_id = null;
  try {
    const rec = await base44.entities.Analisi.create({
      cliente_id: cliente_id || "",
      problema: brief.problema, azione: brief.azione,
      domanda_ricerca: brief.domanda_ricerca || "", metrica_target: brief.metrica_target || "",
      vincoli_specifici: brief.vincoli_specifici || "", override_profilo: brief.override_profilo || {},
      piano, dossier,
      contesto_snapshot: contesto,
      report: typeof report === "string" ? report : JSON.stringify(report),
      asset_url: (asset.file_urls && asset.file_urls[0]) || asset.url || "",
      stato: "eseguita",
    });
    analisi_id = rec?.id || null;
  } catch (_) {}

  return { dossier, report, contesto_snapshot: contesto, analisi_id };
}

// ----- wrapper handler (adatta al template di Base44) -----
// Deno.serve(async (req) => {
//   const base44 = /* client iniettato da Base44 */;
//   const result = await runCMIOV(base44, await req.json());
//   return Response.json(result);
// });
