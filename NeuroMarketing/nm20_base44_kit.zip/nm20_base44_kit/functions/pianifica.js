// pianifica — Router (orchestratore) per Base44
// Dal problema al piano di analisi (sequenza di step CMIOV).
// Versione DETERMINISTICA: euristica + sequenze. Sufficiente per l'MVP.
// Può girare lato client (in una pagina) o come piccola backend function.
//
// TODO: sostituire SEQUENZE con la mappa reale problema->prompt e fase->prompt
//       (le tue PROBLEMI e CMIOV_MAP), e/o usare InvokeLLM per classificare il problema.

export const SEQUENZE = {
  default: [
    { fase: "Conosci", prompt_num: 7,  versione: "base" },
    { fase: "Misura",  prompt_num: 22, versione: "base" },
    { fase: "Misura",  prompt_num: 46, versione: "base" },
    { fase: "Interpreta", prompt_num: 2, versione: "base" },
    { fase: "Ottimizza", prompt_num: 1, versione: "base" },
    { fase: "Verifica", prompt_num: 11, versione: "base" },
  ],
  fiducia: [
    { fase: "Conosci", prompt_num: 7,  versione: "base" },
    { fase: "Misura",  prompt_num: 35, versione: "base" },
    { fase: "Interpreta", prompt_num: 5, versione: "base" },
    { fase: "Ottimizza", prompt_num: 4, versione: "base" },
    { fase: "Verifica", prompt_num: 17, versione: "base" },
  ],
  prezzo: [
    { fase: "Conosci", prompt_num: 12, versione: "base" },
    { fase: "Misura",  prompt_num: 33, versione: "base" },
    { fase: "Interpreta", prompt_num: 31, versione: "base" },
    { fase: "Ottimizza", prompt_num: 27, versione: "base" },
    { fase: "Verifica", prompt_num: 19, versione: "base" },
  ],
  attenzione: [
    { fase: "Conosci", prompt_num: 7,  versione: "base" },
    { fase: "Misura",  prompt_num: 22, versione: "base" },
    { fase: "Interpreta", prompt_num: 3, versione: "base" },
    { fase: "Ottimizza", prompt_num: 2, versione: "base" },
    { fase: "Verifica", prompt_num: 11, versione: "base" },
  ],
};

export function pianifica(problema, promptNums) {
  if (promptNums && promptNums.length) {
    return promptNums.map((n) => ({ fase: "Misura", prompt_num: Number(n), versione: "base" }));
  }
  const p = (problema || "").toLowerCase();
  for (const chiave of Object.keys(SEQUENZE)) {
    if (chiave !== "default" && p.includes(chiave)) return [...SEQUENZE[chiave]];
  }
  return [...SEQUENZE.default];
}
